package com.example.uruG.Servicios;

public class GeneralException extends Exception {
    public GeneralException(String mensaje){
        super(mensaje);
    }
    public GeneralException(){

    }
}
