package com.example.uruG;

public enum EstadoPedido {


        INGRESADO,
        PREPARACION,
        FACTURACION,
        FACTURADO,
        LISTO,
        ENTREGADO,
        ENEDICION

}
