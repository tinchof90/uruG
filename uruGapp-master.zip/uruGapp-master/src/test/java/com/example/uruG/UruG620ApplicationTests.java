package com.example.uruG;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UruG620ApplicationTests {

	@Test
	void contextLoads() {
	}

}
